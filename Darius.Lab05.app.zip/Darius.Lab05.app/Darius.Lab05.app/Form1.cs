namespace Darius.Lab05.app
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double firstNumber = 0;
        string operation = "";
        bool clearDisplayNext = false;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            AppendToDisplay("6");
        }

        private void button5_Click(object sender, EventArgs e)
        {
        HandleChainedOperation("+");
        }

        private void button7_Click(object sender, EventArgs e)
        {
         HandleChainedOperation("x");
        }

        private void screen1_Click(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            AppendToDisplay("1");
        }

        private void AppendToDisplay(string value)
        {
            if (clearDisplayNext)
            {
                txtDisplay.Text = "";
                clearDisplayNext = false;
            }
            txtDisplay.Text += value;
        }
        private double PerformOperation(double a, double b, string op)
        {
            switch (op)
            {
                case "+": return a + b;
                case "-": return a - b;
                case "x": return a * b;
                case "/": return b != 0 ? a / b : 0;
                default: return b;
            }
        }
        private void HandleChainedOperation(string newOp)
        {
            double currentNumber;
            if (double.TryParse(txtDisplay.Text, out currentNumber))
            {
                if (operation != "")
                {
                    firstNumber = PerformOperation(firstNumber, currentNumber, operation);
                    txtDisplay.Text = firstNumber.ToString();
                }
                else
                {
                    firstNumber = currentNumber;
                }
                operation = newOp;
                clearDisplayNext = true;
            }
        }
 
        private void btn2_Click(object sender, EventArgs e)
        {
            AppendToDisplay("2");
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            AppendToDisplay("3");
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            AppendToDisplay("4");
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            AppendToDisplay("5");
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            AppendToDisplay("7");
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            AppendToDisplay("8");
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            AppendToDisplay("9");
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            AppendToDisplay("0");
        }

        private void btndeci_Click(object sender, EventArgs e)
        {
            if (!txtDisplay.Text.Contains("."))
            { AppendToDisplay("."); }
        }

        private void pwr1_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "";
            firstNumber = 0;
            operation = "";
            clearDisplayNext = false;
        }

        private void sub1_Click(object sender, EventArgs e)
        {
        HandleChainedOperation("-");
        }

        private void divide1_Click(object sender, EventArgs e)
        {
        HandleChainedOperation("/");
        }

        private void percent1_Click(object sender, EventArgs e)
        {
            double value;
            if (double.TryParse(txtDisplay.Text, out value))
            {
                value = value / 100;
                txtDisplay.Text = value.ToString();
            }
        }

        private void equal1_Click(object sender, EventArgs e)
        {
            double secondNumber;
            if (double.TryParse(txtDisplay.Text, out secondNumber))
            {
               double result =PerformOperation(firstNumber, secondNumber, operation);
                txtDisplay.Text = result.ToString();
                operation = "";
                clearDisplayNext = false;
            }
        }

        private void clr1_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "";
        }
    }
}
