﻿namespace Darius.Lab05.app
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lcd1 = new Label();
            screen1 = new Label();
            btn1 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btn4 = new Button();
            btn5 = new Button();
            btn6 = new Button();
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btn0 = new Button();
            btndeci = new Button();
            pwr1 = new Button();
            clr1 = new Button();
            add1 = new Button();
            sub1 = new Button();
            multiply1 = new Button();
            divide1 = new Button();
            percent1 = new Button();
            equal1 = new Button();
            txtDisplay = new TextBox();
            SuspendLayout();
            // 
            // lcd1
            // 
            lcd1.AutoSize = true;
            lcd1.Location = new Point(212, 29);
            lcd1.Name = "lcd1";
            lcd1.Size = new Size(0, 15);
            lcd1.TabIndex = 0;
            lcd1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // screen1
            // 
            screen1.AutoSize = true;
            screen1.Location = new Point(468, 72);
            screen1.Name = "screen1";
            screen1.Size = new Size(0, 15);
            screen1.TabIndex = 1;
            screen1.Click += screen1_Click;
            // 
            // btn1
            // 
            btn1.Location = new Point(106, 207);
            btn1.Name = "btn1";
            btn1.Size = new Size(75, 23);
            btn1.TabIndex = 2;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click;
            // 
            // btn2
            // 
            btn2.Location = new Point(212, 207);
            btn2.Name = "btn2";
            btn2.Size = new Size(75, 23);
            btn2.TabIndex = 3;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += btn2_Click;
            // 
            // btn3
            // 
            btn3.Location = new Point(312, 207);
            btn3.Name = "btn3";
            btn3.Size = new Size(75, 23);
            btn3.TabIndex = 4;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += btn3_Click;
            // 
            // btn4
            // 
            btn4.Location = new Point(106, 263);
            btn4.Name = "btn4";
            btn4.Size = new Size(75, 23);
            btn4.TabIndex = 5;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += btn4_Click;
            // 
            // btn5
            // 
            btn5.Location = new Point(212, 263);
            btn5.Name = "btn5";
            btn5.Size = new Size(75, 23);
            btn5.TabIndex = 6;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += btn5_Click;
            // 
            // btn6
            // 
            btn6.Location = new Point(312, 263);
            btn6.Name = "btn6";
            btn6.Size = new Size(75, 23);
            btn6.TabIndex = 7;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += button6_Click;
            // 
            // btn7
            // 
            btn7.Location = new Point(106, 322);
            btn7.Name = "btn7";
            btn7.Size = new Size(75, 23);
            btn7.TabIndex = 8;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += btn7_Click;
            // 
            // btn8
            // 
            btn8.Location = new Point(212, 322);
            btn8.Name = "btn8";
            btn8.Size = new Size(75, 23);
            btn8.TabIndex = 9;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += btn8_Click;
            // 
            // btn9
            // 
            btn9.Location = new Point(312, 322);
            btn9.Name = "btn9";
            btn9.Size = new Size(75, 23);
            btn9.TabIndex = 10;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += btn9_Click;
            // 
            // btn0
            // 
            btn0.Location = new Point(106, 387);
            btn0.Name = "btn0";
            btn0.Size = new Size(75, 23);
            btn0.TabIndex = 11;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = true;
            btn0.Click += btn0_Click;
            // 
            // btndeci
            // 
            btndeci.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btndeci.Location = new Point(212, 387);
            btndeci.Name = "btndeci";
            btndeci.Size = new Size(75, 23);
            btndeci.TabIndex = 12;
            btndeci.Text = ".";
            btndeci.UseVisualStyleBackColor = true;
            btndeci.Click += btndeci_Click;
            // 
            // pwr1
            // 
            pwr1.Location = new Point(529, 207);
            pwr1.Name = "pwr1";
            pwr1.Size = new Size(75, 23);
            pwr1.TabIndex = 14;
            pwr1.Text = "on";
            pwr1.UseVisualStyleBackColor = true;
            pwr1.Click += pwr1_Click;
            // 
            // clr1
            // 
            clr1.Location = new Point(633, 207);
            clr1.Name = "clr1";
            clr1.Size = new Size(75, 23);
            clr1.TabIndex = 15;
            clr1.Text = "clear";
            clr1.UseVisualStyleBackColor = true;
            clr1.Click += clr1_Click;
            // 
            // add1
            // 
            add1.Location = new Point(529, 278);
            add1.Name = "add1";
            add1.Size = new Size(75, 23);
            add1.TabIndex = 16;
            add1.Text = "+";
            add1.UseVisualStyleBackColor = true;
            add1.Click += button5_Click;
            // 
            // sub1
            // 
            sub1.Location = new Point(633, 278);
            sub1.Name = "sub1";
            sub1.Size = new Size(75, 23);
            sub1.TabIndex = 17;
            sub1.Text = "-";
            sub1.UseVisualStyleBackColor = true;
            sub1.Click += sub1_Click;
            // 
            // multiply1
            // 
            multiply1.Location = new Point(529, 322);
            multiply1.Name = "multiply1";
            multiply1.Size = new Size(75, 23);
            multiply1.TabIndex = 18;
            multiply1.Text = "x";
            multiply1.UseVisualStyleBackColor = true;
            multiply1.Click += button7_Click;
            // 
            // divide1
            // 
            divide1.Location = new Point(633, 322);
            divide1.Name = "divide1";
            divide1.Size = new Size(75, 23);
            divide1.TabIndex = 19;
            divide1.Text = "/";
            divide1.UseVisualStyleBackColor = true;
            divide1.Click += divide1_Click;
            // 
            // percent1
            // 
            percent1.Location = new Point(529, 371);
            percent1.Name = "percent1";
            percent1.Size = new Size(75, 23);
            percent1.TabIndex = 20;
            percent1.Text = "%";
            percent1.UseVisualStyleBackColor = true;
            percent1.Click += percent1_Click;
            // 
            // equal1
            // 
            equal1.Location = new Point(633, 371);
            equal1.Name = "equal1";
            equal1.Size = new Size(75, 23);
            equal1.TabIndex = 21;
            equal1.Text = "=";
            equal1.UseVisualStyleBackColor = true;
            equal1.Click += equal1_Click;
            // 
            // txtDisplay
            // 
            txtDisplay.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDisplay.Location = new Point(159, 121);
            txtDisplay.Name = "txtDisplay";
            txtDisplay.ReadOnly = true;
            txtDisplay.Size = new Size(532, 39);
            txtDisplay.TabIndex = 22;
            txtDisplay.TextAlign = HorizontalAlignment.Right;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1091, 666);
            Controls.Add(txtDisplay);
            Controls.Add(equal1);
            Controls.Add(percent1);
            Controls.Add(divide1);
            Controls.Add(multiply1);
            Controls.Add(sub1);
            Controls.Add(add1);
            Controls.Add(clr1);
            Controls.Add(pwr1);
            Controls.Add(btndeci);
            Controls.Add(btn0);
            Controls.Add(btn9);
            Controls.Add(btn8);
            Controls.Add(btn7);
            Controls.Add(btn6);
            Controls.Add(btn5);
            Controls.Add(btn4);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Controls.Add(screen1);
            Controls.Add(lcd1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lcd1;
        private Label screen1;
        private Button btn1;
        private Button btn2;
        private Button btn3;
        private Button btn4;
        private Button btn5;
        private Button btn6;
        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btn0;
        private Button btndeci;
        private Button pwr1;
        private Button clr1;
        private Button add1;
        private Button sub1;
        private Button multiply1;
        private Button divide1;
        private Button percent1;
        private Button equal1;
        private TextBox txtDisplay;
    }
}
